# SLOGrubs prototype: timing model and data

This records the behavior of the delivered demo. It is not a claim of validated restaurant predictions or a final team decision about production data access.

## Definition

“Time to eat” is the time from starting now until food is handed to you or placed at your table. It does not include meal duration or a later trip home after pickup. The current model assumes immediate departure, successful acceptance of any order placed ahead, and no other stops.

Every input is an illustrative [lower, upper] range in minutes. Bounds are propagated through addition and maximum operations, using the corresponding lower and upper endpoints. They are scenario bounds, not estimated statistical confidence intervals.

## Formulas

Let T = example travel time, B = kitchen backlog, P = preparation, Q = queue/order, S = seating, and H = pickup handoff. Food readiness after placing an order is R = B + P.

| Flow | Example formula | Assumption |
| --- | --- | --- |
| Order ahead | max(T, R) + H | Order is accepted now and preparation can proceed while traveling. |
| Dine-in, counter model | T + Q + max(S, R) | Customer orders before looking for a seat, so seating and food preparation overlap. |
| Dine-in, table model | T + S + Q + R | Customer must be seated before ordering; stages happen sequentially. |

Example pickup calculation: T = 12–18, B = 2–4, P = 13–18, H = 1–3. R = 15–22, so total = max(12–18, 15–22) + 1–3 = 16–25 minutes. Travel is counted once.

Driving input ranges include an invented parking allowance. Walking inputs are also invented; neither mode calls a routing API. No customer location is read from the device.

## Demonstration demand

The mixed scenario assigns an invented quiet, steady, or busy state to each restaurant. A quiet state scales B/P/Q/S by 0.75; steady by 1.0; busy by 1.6, rounding each endpoint upward. “All quieter” and “All busier” apply the respective state to all listings. T and H do not change with demand in this demonstration.

These factors and assignments have no empirical basis. They show how a product might react to better information later. A lower kitchen delay does not always shorten an order-ahead total if travel remains the longer stage; that is expected behavior.

## Ranking and filters

- **Soonest food** sorts by the midpoint of each total range. It does not claim an expected value or likelihood.
- **Sample capacity** sorts quiet, steady, busy, breaking ties by the timing midpoint.
- **Name A–Z** sorts the listing names.
- **Entire example range ≤ 30 min** requires the upper bound to be no more than 30, rather than implying a guarantee from the lower bound.
- **Quieter examples only** filters the sample demand state.
- The hero food clock always selects the lowest midpoint among the currently filtered shops, independently of the selected list sort.

## Listing sources

Checked October 29, 2026. Cuisine groupings and neighborhood labels are broad discovery categories, not a representation of review analysis. Counter/table flows are assumptions for demonstration.

| Listing | Address in San Luis Obispo | Listing source |
| --- | --- | --- |
| Firestone Grill | 1001 Higuera St | https://www.firestonegrill.com/locations/firestone-grill-san-luis-obispo/ |
| High Street Deli | 350 High St | https://www.highstdeli.com/location/high-street-deli-high-st/ |
| Old San Luis BBQ Co. | 670 Higuera St | https://downtownslo.com/shop-and-dine/dining/restaurants |
| Woodstock’s Pizza | 1000 Higuera St | https://www.woodstockspizza.com/locations/san-luis-obispo/ |
| Petra Mediterranean | 1210 Higuera St | https://www.eatpetra.com/contact |
| Taqueria Santa Cruz Express | 1308 Monterey St | https://taqueriasce.com/contact |
| Novo Restaurant & Lounge | 726 Higuera St | https://novo-restaurant-lounge.squarespace.com/contact-us |
| Luna Red | 1023 Chorro St | https://www.lunaredslo.com/contact |

Novo’s official homepage, https://www.novorestaurant.com/, links to:
https://order.toasttab.com/online/novo-restaurant-lounge-726-higuera-st

The demo links there; it does not retrieve or validate a live order-ready quote. Other ordering support, service flows, and current hours must be confirmed directly.

## API access is future work

Yelp requires a private API key; it should not be exposed in a public client-side HTML page. See https://docs.developer.yelp.com/docs/places-authentication.

Toast uses authenticated API credentials and scoped restaurant access. Partner credentials involve an approval process, and restaurants authorize a partner integration for their locations. Restaurant-managed access types also exist. Having an external ordering URL does not give SLOGrubs access to operational data. See:

- https://dev.toasttab.com/doc/devguide/authentication.html
- https://doc.toasttab.com/doc/devguide/apiPartnersGettingAccessibleRestaurants.html

A next experiment could compare a restaurant-provided quoted ready time with a small set of actual observations, with that restaurant’s cooperation. Do not treat this demo’s input multipliers as a trained model.

## Validation and practical limits

- The delivered JavaScript passes Node syntax checking.
- Known arithmetic cases check pickup overlap, counter-service overlap, and sequential table service.
- 288 restaurant/time configurations cover eight shops, three origins, two travel modes, two eating modes, and three demand scenarios. Checks cover valid ordered bounds, no impossible total below travel, and ordering by the timing midpoint.
- A small DOM adapter executes the actual application script to check event wiring for switches, search, filters, empty states, reset, sorting, and dialog content; external URLs and text escaping are checked too.
- HTML structure checks verify unique IDs, associated input labels, rendered cards, and no required external assets or packages.
- **A real browser could not be installed in the restricted build environment. Visual layout, native dialog focus/Escape behavior, and touch behavior have not been browser-tested here.** Before presenting, open the local HTML in Edge or Chrome and try it at desktop and phone widths. Native dialogs require a reasonably current browser.
- **No GitHub deployment or live external-link availability test is claimed.** Publishing must be completed in the actual repository. Opening times, provider links, and restaurant operations can change.

Suggested quick presentation check: switch modes; search “Petra”; open its breakdown; change the origin and scenario; reset; resize the window. Then publish the exact same HTML.
