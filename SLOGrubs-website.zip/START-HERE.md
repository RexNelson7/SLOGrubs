# SLOGrubs: first website demo

This is an upload-ready website folder for the existing SLOGrubs R/RStudio repository. It requires no R packages, Node packages, server, API keys, or build process.

## See it right now

1. Extract `SLOGrubs-website.zip` (on Windows: right-click → **Extract All**).
2. Open `docs/index.html` in Chrome, Edge, Firefox, or Safari.
3. Try **Order ahead / Eat there**, the origin and travel selectors, and the demand scenario. Open a shop’s **See time breakdown** button.

The restaurant list, filters, formulas, and dialogs work offline. Yelp, restaurant websites, Google Maps directions, and Novo’s Toast ordering page need internet access because they are external links.

## Put it in the shared GitHub repo

Repository: https://github.com/RexNelson7/SLOGrubs

The repository could not be read or written from the build environment. Nothing has been pushed or published. These files were prepared separately, based on the team’s description that the repo contains an R project and no website.

1. Open the repository on GitHub and select the branch you want to publish, usually `main`.
2. Check for an existing `docs/index.html` first. If one exists, inspect it before replacing it. This package does not need changes to `.Rproj`, R scripts, or your existing README.
3. Click **Add file → Upload files**. Drag the extracted **docs folder** into the upload area. Verify GitHub shows `docs/index.html`, not just `index.html` at the repo root. Commit the upload. You may include the two Markdown guides if helpful; they are optional.
4. Open **Settings → Pages**. Under **Build and deployment**, set **Source** to **Deploy from a branch**. Select your branch and **/docs**, then click **Save**.
5. Check the repo’s **Actions** tab for a successful Pages deployment. The Pages settings screen will show the published URL once it is ready. Publishing can take several minutes.

For the repository above, the expected default URL after successful deployment is:

https://rexnelson7.github.io/SLOGrubs/

This URL is the expected destination, not a verified live deployment.

### Even simpler alternative: create one file

If folder upload is awkward, download the standalone `index.html` supplied with the demo. On GitHub, click **Add file → Create new file**, enter `docs/index.html` as the filename, paste the downloaded HTML file’s entire contents, and commit. Then configure Pages as above. On Windows, right-click the downloaded HTML → **Open with → Notepad** to copy its source.

`docs/.nojekyll` disables Jekyll processing when present. It is optional for this HTML-only page; the page has no Jekyll-dependent content. Browser folder uploads may omit hidden files, which is okay here.

### If publishing needs troubleshooting

- **No Settings/Pages access:** a repository admin or maintainer must configure Pages.
- **Pages unavailable:** GitHub Free supports Pages for public repositories; private repositories require an eligible paid plan. Follow the actual options in your repository rather than changing repository visibility without your team’s agreement.
- **404:** check the selected branch, `/docs`, and the exact path `docs/index.html`, then wait for the Pages workflow to succeed. Check capitalization in the site URL.
- **Old version:** confirm the commit reached the publishing branch, wait for deployment, then hard-refresh the page.
- **HTML shown as text on github.com:** GitHub’s Code tab displays source. Use the published `github.io` URL, or open the downloaded HTML locally.

GitHub’s current publishing instructions:
https://docs.github.com/en/pages/getting-started-with-github-pages/configuring-a-publishing-source-for-your-github-pages-site

## What is in this version

- Eight real SLO restaurant listings with source links.
- Yelp search links and restaurant website links, plus Google Maps directions in each time-breakdown dialog.
- Novo’s Toast ordering page linked from its official website, as an external link only.
- A “time to eat” range with visible, simplified calculations.
- Pickup/order-ahead and two illustrative dine-in service flows.
- Three example starting areas, walking/driving examples, and demand scenarios.
- Search, cuisine filters, an upper-bound 30-minute filter, sample capacity filtering, and sorting.
- Responsive CSS, keyboard focus styles, labeled inputs, a skip link, and native dialogs for modern browsers.
- No accounts, submissions, analytics, external assets, or paid placements.

## What is real versus simulated

**Real:** restaurant names, addresses, official website links, and cited listing sources, checked October 29, 2026.

**Simulated:** all travel times, preparation times, kitchen backlogs, seating/ordering/handoff times, demand levels, and resulting ranges. Counter/table service classifications are example assumptions, not verified operational data. Listings do not imply partnerships. The directory is illustrative and incomplete.

**Not connected:** Yelp API, Toast API, maps/routing API, opening-hours checks, live queues, reservations, or ordering. No Yelp ratings or review counts are imported, and no review-derived speed score is invented. An external ordering link is not an integration and may change.

The demo does not filter out restaurants that may currently be closed. Ask users to check opening hours and actual waits on the restaurant’s site before making real plans.

## Edit it with your team

All website code is in `docs/index.html`:

- Search for `const RESTAURANTS` to edit listing metadata and example inputs.
- Search for `function estimate` to edit the timing model.
- Search for `:root` to edit colors.
- Search for `DEFAULTS` to edit the initial settings.

Keep sample labels visible while the numbers are invented. Never commit Yelp/Toast API keys or other secrets into this HTML. Live data needs an appropriate authenticated integration outside this static page; provider terms and actual access still need checking.

See `MODEL-AND-DATA.md` for formulas, sources, limitations, and validation notes.
